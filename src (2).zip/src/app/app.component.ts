import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PaginationInstance } from 'ngx-pagination';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent {

  dataArray: any[] = [];
  isError: boolean = false;
  isOnEdit: boolean = false;
  order: boolean = false;
  isDesc: boolean = false;
  user: any = {};
  gendersOption: any = ['male', 'female']
  saveData: any = {}
  directionLinks: boolean = true;
  autoHide: boolean = false;
  responsive: boolean = false;
  currentUserId: any
  config: PaginationInstance = {
    id: 'advanced',
    itemsPerPage: 5,
    currentPage: 1
  };
  labels: any = {
    previousLabel: 'Previous',
    nextLabel: 'Next',
  };

  constructor() { 
  }

  ngOnInit() {
    this.dataArray = JSON.parse(localStorage.getItem('Users')!);
  }
 
  formData = new FormGroup({
    id: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.minLength(1), Validators.maxLength(10)]),
    name: new FormControl('', [Validators.required, Validators.pattern('(([A-Z])*([a-z])*)*')]),
    gender: new FormControl('', [Validators.required]),
    contact: new FormControl('', [Validators.required, Validators.pattern('[0-9]{10}')]),
    address: new FormControl('', [Validators.required]),
  });


  addUser(user: any) {
    // let dataArray:any = []
    if (localStorage.getItem('Users')) {
      this.dataArray = JSON.parse(localStorage.getItem('Users')!);
      this.dataArray = [user, ...this.dataArray];
    }
    else {
      this.dataArray = [user]
    }
    localStorage.setItem('Users', JSON.stringify(this.dataArray));
  }

  onSubmit() {
    console.log(this.formData.value);
    this.user = Object.assign(this.user, this.formData.value);
    this.addUser(this.user);
    this.formData.reset();
  }

  // Modal open with selected row data
  onEdit(item: any) {
    this.isOnEdit = true;
    this.formData.setValue({
      id: item.id,
      name: item.name,
      gender: item.gender,
      contact: item.contact,
      address: item.address,
    });
    this.currentUserId = this.formData.value.id
    this.saveData = this.formData.value
  }

  // for unique id concept. if id repeat then it will show error
  idChange(event: any) {
    this.isError = false;
    this.dataArray.map((element, index) => {
      if (this.dataArray[index].id == event.target.value) {
        this.isError = true;
      }
    });
    if (this.isError) {
      this.formData.controls.id.setErrors({ idExist: true });
    }
  }

  updateDisable() {
    if (this.saveData.id != this.formData.controls.id.value?.trim() || this.saveData.name != this.formData.controls.name.value?.trim() || this.saveData.gender != this.formData.controls.gender.value || this.saveData.contact != this.formData.controls.contact.value?.trim() || this.saveData.address != this.formData.controls.address.value?.trim()) {
      return false;
    }
    return true;
  }

  // On edit button we can edit row data and submit using update button
  onUpdate(selectedrow: any) {
    this.dataArray.forEach((element, index) => {
      if (this.dataArray[index].id === this.currentUserId) {
        this.dataArray[index] = selectedrow
        console.log(this.dataArray[index])
      }
    });
    localStorage.setItem('Users', JSON.stringify(this.dataArray));
    this.formData.reset();
    this.isOnEdit = false;
  }

  onClose() {
    this.isOnEdit = false;
    this.formData.reset();
  }

  sortAddress(nameValue: any) {
    this.isDesc = !this.isDesc;
    let direction = this.isDesc ? 1 : -1;
    this.dataArray.sort(function (a: any, b: any) {
      if (a[nameValue] < b[nameValue]) {
        return -1 * direction;
      } else if (a[nameValue] > b[nameValue]) {
        return 1 * direction;
      } else {
        return 0;
      }
    });
  }
}
