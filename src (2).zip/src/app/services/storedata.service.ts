import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StoredataService {

  constructor() {}
  
  addUser(user: any) {
    let dataArray = []
    if (localStorage.getItem('Users')) {
      dataArray = JSON.parse(localStorage.getItem('Users')!);
      dataArray = [user, ...dataArray];
    }
    else{
      dataArray = [user]
    }
    localStorage.setItem('Users', JSON.stringify(dataArray));
  }

}
