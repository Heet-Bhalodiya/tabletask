import { Component, EventEmitter, Input, OnInit, Output, SimpleChange } from '@angular/core';
import { PaginationInstance } from 'ngx-pagination';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})

export class TableComponent implements OnInit {
  isError: boolean = false;
  isOnEdit: boolean = false;
  globalSearch: string = '';
  nameSearch: string = '';
  contactSearch: any = ''
  idSearch: any = '';
  genderSort: string = '';
  order: boolean = false;
  isDesc: boolean = false;
  user: any = {};
  gendersOption: any = ['male', 'female']
  Object = Object;
  tableHead: any = { "Sr. No.": '', "ID": '', "Name": '', "Gender": '', "Contact": '', "Address": '', "Action": '' };
  saveData: any = {}
  directionLinks: boolean = true;
  autoHide: boolean = false;
  responsive: boolean = false;
  currentUserId: any;
  rowCount: number = 1;
  config: PaginationInstance = {
    id: 'advanced',
    itemsPerPage: 3,
    currentPage: 1,
  };
  labels: any = {
    previousLabel: 'Previous',
    nextLabel: 'Next',
  };

  @Input() userRecords: any = []
  @Output() selectedFormValue = new EventEmitter<any>()
  // @Output() rowNumCount = new EventEmitter<number>()
  // sendData(){
  //   this.rowNumCount.emit(this.rowCount)
  // } 

  constructor() {
  }

  ngOnInit(){
    this.onPageChange(this.rowCount)
  }
 
  // disable text while searching id or contact, it only allow number values 
  keyPressNumber(event:any){
    return event.charCode >= 48 && event.charCode <= 57
  }

  // disable number while searching name, it only allow text 
  keyPressName(event:any){
    return event.charCode >=65  && event.charCode <= 90 || event.charCode >=97 && event.charCode <=122
  }
  
  // delete selected row from the table 
  onDelete(index: number) {
    if (confirm("Are you sure want to delete " + this.userRecords[index].name + " record")) {
      let ind = this.userRecords.indexOf(this.userRecords[index]);
      if (ind > -1) {
        this.userRecords.splice(ind, 1);
      }
    }
    localStorage.setItem('Users', JSON.stringify(this.userRecords));
  }

  // on edit table row it will send the form data to parent component "app-component"
  onEdit(item: any) {
    this.selectedFormValue.emit(item)
  }

  // when page change then function call and total row count calculated from here 
  onPageChange(number: number) {
    this.config.currentPage = number;
    let totalData = this.userRecords.length;
    let num = Math.floor(totalData / this.config.itemsPerPage);
    let module = totalData % this.config.itemsPerPage
    if (totalData < this.config.itemsPerPage) {
      this.rowCount = (totalData % this.config.itemsPerPage)
    }
    else {
      for (let i = 1; i <= num; i++) {
        if (this.config.currentPage <= num) {
          this.rowCount = this.config.itemsPerPage
        }
        else {
          this.rowCount = module
        }
      }
    }
  }

  onPageBoundsCorrection(number: number) {
    this.config.currentPage = number;
  }

  // for sorting table column : ID
  sortId() {
    if (this.order) {
      let sortedId = this.userRecords.sort((a: { id: number; }, b: { id: number; }) => a.id - b.id);
      this.userRecords = sortedId;
    } else {
      let sortId = this.userRecords.sort((a: { id: number; }, b: { id: number; }) => b.id - a.id);
      this.userRecords = sortId;
    }
    this.order = !this.order;
  }

  // for sorting table column : contact
  sortContact() {
    if (this.order) {
      let sortedContact = this.userRecords.sort((a: { contact: number; }, b: { contact: number; }) => a.contact - b.contact);
      this.userRecords = sortedContact;
    } else {
      let sortedContact = this.userRecords.sort((a: { contact: number; }, b: { contact: number; }) => b.contact - a.contact);
      this.userRecords = sortedContact;
    }
    this.order = !this.order;
  }

  // for sorting table column : Name
  sortName(nameValue: any) {
    this.isDesc = !this.isDesc;
    let direction = this.isDesc ? 1 : -1;
    this.userRecords.sort(function (a: string, b: string) {
      if (a[nameValue] < b[nameValue]) {
        return -1 * direction;
      } else if (a[nameValue] > b[nameValue]) {
        return 1 * direction;
      } else {
        return 0;
      }
    });
  }

  // for sorting table column : address 
  sortAddress(nameValue: any) {
    this.isDesc = !this.isDesc;
    let direction = this.isDesc ? 1 : -1;
    this.userRecords.sort(function (a: any, b: any) {
      if (a[nameValue] < b[nameValue]) {
        return -1 * direction;
      } else if (a[nameValue] > b[nameValue]) {
        return 1 * direction;
      } else {
        return 0;
      }
    });
  }
    
}
