import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PaginationInstance } from 'ngx-pagination';
import { StoredataService } from './services/storedata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent {
  dataArray: any[] = [];
  isError: boolean = false;
  isOnEdit: boolean = false;
  globalSearch: string = '';
  nameSearch: string = '';
  contactSearch: any = ''
  idSearch: any = '';
  genderSort: string = '';
  order: boolean = false;
  isDesc: boolean = false;
  user: any = {};
  gendersOption: any = ['male', 'female']
  Object = Object;
  tableHead: any = { "Sr. No." : '', "ID": ' ', "Name": ' ', "Gender":'', "Contact":' ', "Address": '', "Action": ' '}
  saveData:any = {}
  directionLinks: boolean = true;
  autoHide: boolean = false;
  responsive: boolean = false;
  currentUserId:any 
  config: PaginationInstance = {
    id: 'advanced',
    itemsPerPage: 5,
    currentPage: 1
  };
  labels: any = {
    previousLabel: 'Previous',
    nextLabel: 'Next',
  };
  public eventLog: string[] = [];

  private popped = [];

  onPageChange(number: number) {
      this.logEvent(`pageChange(${number})`);
      this.config.currentPage = number;
  }

  onPageBoundsCorrection(number: number) {
      this.logEvent(`pageBoundsCorrection(${number})`);
      this.config.currentPage = number;
  }

  pushItem() {
      let item = this.popped.pop() || 'A newly-created meal!';
      this.dataArray.push(item);
  }

  popItem() {
      // this.popped.push( this.dataArray.pop());
  }

  private logEvent(message: string) {
      this.eventLog.unshift(`${new Date().toISOString()}: ${message}`)
  }

  constructor() { }
  
  ngOnInit() {
    this.dataArray = JSON.parse(localStorage.getItem('Users')!);
  }

  formData = new FormGroup({
    id: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'), Validators.minLength(1), Validators.maxLength(10)]),
    name: new FormControl('', [Validators.required, Validators.pattern('(([A-Z])*([a-z])*)*')]),
    gender: new FormControl('', [Validators.required]),
    contact: new FormControl('', [Validators.required, Validators.pattern('[0-9]{10}')]),
    address: new FormControl('', [Validators.required]),
  });

  // onPageChange(number: number) {
  //   this.config.currentPage = number;
  // }

  // onPageBoundsCorrection(number: number) {
  //   this.config.currentPage = number;
  // }

  addUser(user: any) {
    // let dataArray:any = []
  if (localStorage.getItem('Users')) {
    this.dataArray = JSON.parse(localStorage.getItem('Users')!);
    this.dataArray = [user, ...this.dataArray];
  }
  else {
    this.dataArray = [user]
  }
  localStorage.setItem('Users', JSON.stringify(this.dataArray));
}

  onSubmit() {
    console.log(this.formData.value);
    this.user = Object.assign(this.user, this.formData.value);
    this.addUser(this.user);
    this.formData.reset();
  }

  // delete particular row from the table
  onDelete(index: any) {
    if (confirm("Are you sure want to delete " + this.dataArray[index].name + " record")) {
      let ind = this.dataArray.indexOf(this.dataArray[index]);
      if (ind > -1) {
        this.dataArray.splice(ind, 1);
      }
    }
    localStorage.setItem('Users', JSON.stringify(this.dataArray));
  }

  // Modal open with selected row data
  onEdit(item: any) {
    this.isOnEdit = true;
    this.formData.setValue({
      id: item.id,
      name: item.name,
      gender: item.gender,
      contact: item.contact,
      address: item.address,
    });
    this.currentUserId = this.formData.value.id
    this.saveData = this.formData.value

  }

  // for unique id concept. if id repeat then it will show error
  idChange(event: any) {
    this.isError = false;
    this.dataArray.map((element, index) => {
      if (this.dataArray[index].id == event.target.value) {
        this.isError = true;
      }
    });
    if (this.isError) {
      this.formData.controls.id.setErrors({ idExist: true });
    }
  }
  
  updateDisable(){
    if(this.saveData.id != this.formData.controls.id.value?.trim() || this.saveData.name != this.formData.controls.name.value?.trim() || this.saveData.gender != this.formData.controls.gender.value || this.saveData.contact != this.formData.controls.contact.value?.trim() || this.saveData.address != this.formData.controls.address.value?.trim()){
        return false;
    }
    return true;
  }

  // On edit button we can edit row data and submit using update button
  onUpdate(selectedrow: any) {
    this.dataArray.forEach((element, index) => {
      if (this.dataArray[index].id === this.currentUserId) {
        this.dataArray[index] = selectedrow 
        console.log(this.dataArray[index]) 
         }
    });
    localStorage.setItem('Users', JSON.stringify(this.dataArray));
    // this.appComponent.refreshUser(this.dataArray)
    this.formData.reset();
    this.isOnEdit = false;
  }

  onClose() {
    this.isOnEdit = false;
    this.formData.reset();
  }

  // for sorting table column : ID
  sortId() {
    if (this.order) {
      let sortedId = this.dataArray.sort((a, b) => a.id - b.id);
      this.dataArray = sortedId;
    } else {
      let sortId = this.dataArray.sort((a, b) => b.id - a.id);
      this.dataArray = sortId;
    }
    this.order = !this.order;
  }

  // for sorting table column : contact
  sortContact() {
    if (this.order) {
      let sortedContact = this.dataArray.sort((a, b) => a.contact - b.contact);
      this.dataArray = sortedContact;
    } else {
      let sortedContact = this.dataArray.sort((a, b) => b.contact - a.contact);
      this.dataArray = sortedContact;
    }
    this.order = !this.order;
  }

  // for sorting table column : Name
  sortName(nameValue: any) {
    this.isDesc = !this.isDesc;
    let direction = this.isDesc ? 1 : -1;
    this.dataArray.sort(function (a: any, b: any) {
      if (a[nameValue] < b[nameValue]) {
        return -1 * direction;
      } else if (a[nameValue] > b[nameValue]) {
        return 1 * direction;
      } else {
        return 0;
      }
    });
  }
}
