import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { SearchFilterPipe } from './pipes/serachfilter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSliderModule } from '@angular/material/slider';
import { NgxPaginationModule } from 'ngx-pagination';
import { GendersortPipe } from './pipes/gendersort.pipe'
import { StoredataService } from './services/storedata.service';
  

@NgModule({
  declarations: [
    AppComponent,
    SearchFilterPipe,
    GendersortPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatSliderModule,
    NgxPaginationModule
    // DataTablesModule,
  ],
  providers: [StoredataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
